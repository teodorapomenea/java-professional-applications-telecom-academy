import java.util.concurrent.atomic.AtomicInteger;

public class Runnable5 implements Runnable{
    AtomicInteger x = new AtomicInteger(0);
    @Override
    public void run() {
        for(int i = 0; i < 20; i++){
            System.out.println(x.getAndIncrement()); //x++
        }
    }
}
