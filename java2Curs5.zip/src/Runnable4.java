import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Runnable4 implements Runnable {
    private CyclicBarrier barrier = new CyclicBarrier(2);
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName());
        try {
            barrier.await();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            e.printStackTrace();
        }
    }
}
