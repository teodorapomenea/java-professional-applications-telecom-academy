import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplul14 {
    public static void main(String[] args) {
        Runnable5 task = new Runnable5();
        ExecutorService service = Executors.newFixedThreadPool(3);
        service.execute(task);
        service.execute(task);
        service.execute(task);

        service.shutdown();
    }
}
