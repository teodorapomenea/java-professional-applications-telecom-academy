public class SimpleThread implements Runnable {
    @Override
    public void run() {
        getData();
    }

    public synchronized static void getData(){
        while(true){
            //getting data
            if(1 == 1){
               /* try {
                    Thread.sleep(200);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                break;*/
            }
        }
    }
}
