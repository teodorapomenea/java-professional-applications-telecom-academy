import java.time.Instant;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Exemplul11 {
    public static void main(String[] args) {
        Runnable1 task = new Runnable1();
        ScheduledExecutorService service = Executors.newSingleThreadScheduledExecutor();
        System.out.println(Instant.now());
        service.schedule(task, 2, TimeUnit.SECONDS);
        service.schedule(task, 2, TimeUnit.SECONDS);
        service.shutdown();
    }
}
