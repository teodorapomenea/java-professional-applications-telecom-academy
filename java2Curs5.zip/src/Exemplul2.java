public class Exemplul2 {
    public static void main(String[] args) {
        NumerePare np = new NumerePare();
        np.start();
        System.out.println(":)");

        NumereImpare ni = new NumereImpare();
        Thread thread = new Thread(ni);
        thread.start();
    }
}
