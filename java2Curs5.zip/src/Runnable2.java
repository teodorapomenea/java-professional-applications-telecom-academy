import java.util.concurrent.Semaphore;

public class Runnable2 implements Runnable {
    int x;
    private Semaphore semaphore = new Semaphore(1);
    @Override
    public void run() {
        for(int i = 0; i < 20; i++){
            try {
                semaphore.acquire();
                System.out.println(++x);
                semaphore.release();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }
}
