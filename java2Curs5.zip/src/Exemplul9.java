import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplul9 {
    public static void main(String[] args) {
        Runnable run = () -> System.out.println(Thread.currentThread().getName());
        ExecutorService service = Executors.newCachedThreadPool();

        service.execute(run);
        service.execute(run);
        service.execute(run);
        service.execute(run);
        service.execute(run);
        service.execute(run);

        service.shutdown();

    }
}
