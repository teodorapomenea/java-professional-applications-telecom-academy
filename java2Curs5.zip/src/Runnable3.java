import java.util.concurrent.locks.ReentrantReadWriteLock;

public class Runnable3 implements Runnable{
    int x;
    private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

    @Override
    public void run() {
        for(int i = 0; i < 20; i++){
            read();
            write();
        }
    }

    public void read(){
        lock.readLock().lock();
        String name = Thread.currentThread().getName();
        System.out.println(name + " citeste " + x);
        System.out.println(name + " a terminat de citit " + x);
        lock.readLock().unlock();
    }

    public void write(){
        lock.writeLock().lock();
        String name = Thread.currentThread().getName();
        System.out.println(name + " scrie " + x);
        x++;
        System.out.println(name + " a terminat de scris " + x);
        lock.writeLock().unlock();
    }
}
