public class Exemplul5 {
    public static void main(String[] args) throws InterruptedException {
        Thread main = Thread.currentThread();
        Thread thread = new Thread(() -> {
            //Runnable
            System.out.println(main.getState());
        });
        thread.start();
        thread.join();
    }
}
