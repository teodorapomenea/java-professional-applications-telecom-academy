public class Exemplul3 {
    public static void main(String[] args) {
        Runnable task = () -> System.out.println("Hello");
        Thread thread = new Thread(task);
        thread.start();
        System.out.println(thread.getState());
    }
}
