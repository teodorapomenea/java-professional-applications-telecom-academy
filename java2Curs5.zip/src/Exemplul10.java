import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Exemplul10 {
    public static void main(String[] args) {
        CallableImplementation callableImplementation = new CallableImplementation();
        ExecutorService service = Executors.newSingleThreadExecutor();
        Future<Integer> result = service.submit(callableImplementation);
        try {
            if(result.isDone()) {
                System.out.println(result.get());
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        //result.cancel(true); -> anuleaza taskul
        service.shutdown();
    }
}
