public class Exemplul4 {
    public static void main(String[] args) throws InterruptedException {
        SimpleThread st = new SimpleThread();
        Thread thread1 = new Thread(st);
        Thread thread2 = new Thread(st);

        thread1.start();
        thread2.start();
        Thread.sleep(2000);
        System.out.println(thread2.getState());

    }
}
