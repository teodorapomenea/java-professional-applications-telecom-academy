import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplul7 {
    public static void main(String[] args) {
        ExecutorService service = Executors.newSingleThreadExecutor();
        Runnable task = () -> System.out.println(Thread.currentThread().getName());
        service.execute(task);
        service.execute(task);
        service.shutdown();

    }
}
