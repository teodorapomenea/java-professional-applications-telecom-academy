import java.util.Locale;
import java.util.ResourceBundle;

public class Exemplul1 {
    public static void main(String[] args) {
        Locale loc = new Locale("fr_FR");
        ResourceBundle bundle = ResourceBundle.getBundle("hello", loc);
        String hello = bundle.getString("tree_key");
        System.out.println(hello);
        System.out.println(Locale.getDefault());
    }
}
