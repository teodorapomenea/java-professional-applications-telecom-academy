import java.time.Instant;

public class Runnable1 implements Runnable {
    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        Instant instant = Instant.now();
        System.out.println(name + " " + instant);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
