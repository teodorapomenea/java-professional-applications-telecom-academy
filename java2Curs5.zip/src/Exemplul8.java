import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Exemplul8 {
    public static void main(String[] args) {
        Runnable task = () -> System.out.println(Thread.currentThread().getName());
        ExecutorService service = Executors.newFixedThreadPool(3);

        service.execute(task);
        service.execute(task);
        service.execute(task);
        service.execute(task);
        service.execute(task);
        service.execute(task);
        service.shutdown();
    }
}
