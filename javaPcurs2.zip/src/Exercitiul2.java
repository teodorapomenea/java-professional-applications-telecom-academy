import java.io.File;
import java.io.IOException;

public class Exercitiul2 {
    public static void main(String[] args) {
        File f = new File("A/B/C");
        f.mkdir();
        File f1 = new File("B/C/D");
        f1.mkdirs();
        File f2 = new File("B/C/fisier2.txt");
        try {
            f2.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }

        File f3 = new File("B/C/");
        File [] lista = f3.listFiles();
        for(File i : lista){
            System.out.println(i);
        }


    }
}
