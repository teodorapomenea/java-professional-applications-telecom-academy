import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercitiul5 {
    public static void main(String[] args) {
        Path p = Paths.get("A/C/D/B");
        System.out.println(p.getNameCount());

        Path p1 = p.toAbsolutePath();
        System.out.println(p1);
        p1 = Paths.get("C:/");
        System.out.println(p1.getNameCount());

        Path p2 = p.subpath(0,2);
        System.out.println(p2);
    }
}
