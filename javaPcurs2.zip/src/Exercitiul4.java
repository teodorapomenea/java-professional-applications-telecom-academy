import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercitiul4 {
    public static void main(String[] args) {
        Path p = Path.of("A/B/V/J/L");
        Path p1 = Paths.get("A/B/C/D");

        System.out.println(p1.getFileName());
        System.out.println(p1.getParent());
        System.out.println(p1.getRoot());
        System.out.println(p1.isAbsolute());
        System.out.println(p1.getName(1));

        Path p2 = p1.toAbsolutePath();
        System.out.println();

        System.out.println(p2.getFileName());
        System.out.println(p2.getParent());
        System.out.println(p2.getRoot());
        System.out.println(p2.isAbsolute());
        System.out.println(p2.getName(0));


    }
}
