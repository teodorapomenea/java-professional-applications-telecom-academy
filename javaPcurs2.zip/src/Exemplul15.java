import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Exemplul15 {
    public static void main(String[] args) throws IOException {
        Path p = Paths.get("./");
         Stream<Path> pathStream = Files.find(p, Integer.MAX_VALUE,
                                (path, ba) -> path.getFileName().toString().endsWith(".java"));
         pathStream.forEach(e -> System.out.println(e));
    }
}
