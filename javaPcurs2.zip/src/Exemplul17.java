//CD -> schimba directorul
//MKDIR -> creeze un director
//CF -> creaza un fisier
//DL -> sterge un fisier/director
//LS -> returneaza lista fisierelor
//EXIT -> iese din aplicatie

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Exemplul17 {
    public static void main(String[] args) {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);
        //Adaugarea unui case care sa reseteze pathul la cel original
        //Adaugati un case care se intorce inapoi cu un director
        //Stergerea unui fisier care nu este gol
        try(isr; br;){
            Path p = Paths.get("./");
            while(true) {
                String s = br.readLine();
                String[] cmd = s.split("\\s++");
                switch (cmd[0].toLowerCase()) {
                    case "sp":
                        System.out.println(p);
                        break;
                    case "cd":
                        Path p1 = Paths.get(cmd[1]);
                        p = p.resolve(p1);
                        System.out.println(p);
                        break;

                    case "mkdir":
                        Path p2 = Paths.get(cmd[1]);
                        Path p21 = p.resolve(p2);
                        Files.createDirectories(p21);
                        break;

                    case "cf":
                        Path p3 = Paths.get(cmd[1]);
                        p3 = p.resolve(p3);
                        Files.createFile(p3);
                        break;

                    case "dl":
                        Path p4 = p.resolve(cmd[1]);
                        //Verificati daca exita
                        //Daca nu sa se afiseze un mesaj
                        Files.deleteIfExists(p4);
                        System.out.println("S-a ster fisierul");
                        break;

                    case "ls":
                        Path p5 = p.resolve(cmd[1]);
                        Files.list(p5).forEach(e -> System.out.println(e));
                        break;

                    case "exit":
                        System.exit(0);
                        break;

                    default:
                        System.out.println("Comanda gresita");

                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
