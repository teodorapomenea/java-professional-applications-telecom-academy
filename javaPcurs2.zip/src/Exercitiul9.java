import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercitiul9 {
    public static void main(String[] args) throws IOException {
        Path p = Paths.get("A/B/fisierSrc.txt");
        BufferedWriter bw = Files.newBufferedWriter(p);
        bw.write(":)");
        bw.newLine();
        bw.write("Buna ziua!");
        bw.close();
    }
}
