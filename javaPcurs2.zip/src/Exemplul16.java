import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Exemplul16 {
    public static void main(String[] args) throws IOException {
        Path p = Paths.get("B/fisierDest.txt");
        List<String> lista = Files.readAllLines(p);
        lista.forEach(e -> System.out.println(e));
    }
}
