import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;

public class Exemplul12 {
    public static void main(String[] args) throws IOException {
        Path p1 = Paths.get("B/fisierDest.txt");
        BasicFileAttributes basicFileAttributes = Files.readAttributes(p1, BasicFileAttributes.class);
        System.out.println(basicFileAttributes.creationTime());
        System.out.println(basicFileAttributes.lastAccessTime());
    }
}
