import java.io.File;

public class Exercitiul3 {
    public static void main(String[] args) {
        File f = new File("B/C");
        f.delete();
    }
}
