import java.io.File;
import java.io.IOException;

public class Exercitiul1 {
    public static void main(String[] args) {
        File f = new File("fisier1.txt");
        try {
            boolean rez = f.createNewFile();
            System.out.println(rez);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
