import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercitiul8 {
    public static void main(String[] args) {
        Path p = Paths.get("A/B/C");
        try {
           // Files.createDirectory(p);
            Files.createDirectories(p);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Path p1 = Paths.get("A/B/fisier.txt");

        try {
            boolean rez = Files.notExists(p1);
            if(rez) {
                Files.createFile(p1);
            }else{
                System.out.println("Fisierul exsita");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            Files.delete(p1);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
