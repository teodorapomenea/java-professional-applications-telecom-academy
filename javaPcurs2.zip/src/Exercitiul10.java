import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class Exercitiul10 {
    public static void main(String[] args) {
        Path p = Paths.get("A/B/fisierSrc.txt");
        Path p1 = Paths.get("B/fisierDest.txt");
        try {
            //Files.createFile(p);
            Files.copy(p,p1, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
