import java.nio.file.Path;
import java.nio.file.Paths;

public class Exercitiul6 {
    public static void main(String[] args) {
        Path p = Paths.get("C:/A/B/../C/././D/E/../F");
        System.out.println(p.normalize());
        p = p.normalize();
        Path p2 = Paths.get("C:/X/Y/Z");
        Path p3 = p2.resolve(p);
        System.out.println(p3);


    }
}
