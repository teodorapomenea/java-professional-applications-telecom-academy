import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class Exemplul13 {
    public static void main(String[] args) {
        Path p = Paths.get("./");
        try {
            Stream<Path> pathStream = Files.walk(p);
            pathStream.forEach(e -> System.out.println(e));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
