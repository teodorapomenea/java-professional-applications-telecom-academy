import java.io.Serializable;

public class Pisica implements Serializable {
    public static final long serialVersionUID = 1L;
    private String culoare;
    private int varsta;
    private transient int greutate = 12;

    public Pisica(String culoare, int varsta) {
        this.culoare = culoare;
        this.varsta = varsta;
        System.out.println("Constructor!");
    }

    public String getCuloare() {
        return culoare;
    }

    public void setCuloare(String culoare) {
        this.culoare = culoare;
    }

    public int getVarsta() {
        return varsta;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    @Override
    public String toString() {
        return "Pisica{" +
                "culoare='" + culoare + '\'' +
                ", varsta=" + varsta +
                ", greutate=" + greutate +
                '}';
    }
}
