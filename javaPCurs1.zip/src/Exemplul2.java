import java.io.*;

public class Exemplul2 {
    public static void main(String[] args) throws IOException {
        FileOutputStream fos = new FileOutputStream("fisier.txt");
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        BufferedWriter bw = new BufferedWriter(osw);

        try(fos; osw; bw;){
            bw.write("Hello, Mira!");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
