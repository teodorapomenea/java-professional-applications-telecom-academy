import java.io.*;

public class Exemplul6 {
    public static void main(String[] args) throws IOException {
        Pisica p = new Pisica("Mitzi", 5);

        FileOutputStream fos = new FileOutputStream("pisica.seri");
        BufferedOutputStream bos = new BufferedOutputStream(fos);
        ObjectOutputStream oos = new ObjectOutputStream(bos);

        try(fos; bos; oos){
            oos.writeObject(p);
        }catch(IOException e){
            e.printStackTrace();
        }


    }
}
