import java.io.*;

public class Exemplul4 {
    public static void main(String[] args) throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        FileOutputStream fos = new FileOutputStream("exercitiu.txt");
        OutputStreamWriter osw = new OutputStreamWriter(fos);
        BufferedWriter bw = new BufferedWriter(osw);

        try(isr; br; fos; osw; bw;) {
            String line = br.readLine();

            while(!line.equals("exit")) {
                bw.write(line);
                bw.newLine();
                if(line.equals("exit"))
                    break;
                line = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
