
//  "scriere"  -> va scrie test intr-un fisier exercitiuSuplimentar.txt de 5 ori
// "serializare" -> va face serializarea pentru o instanta de student
            // -> atributele vor fi introduse de la tastatura
//"deserializare" -> va excuta deserializarea insatntei + afisarea ei
//clasa student are ca atribute nume, prenume, varsta


import java.io.*;


public class Exemplul8 {
    public static void main(String[] args) throws IOException {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        PrintWriter pw = new PrintWriter("ExercitiuSuplimentar.txt");



        System.out.println("Introduceti comanda!");
        String cmd = br.readLine();
        switch (cmd){
            case "scriere":
                try(pw) {
                    int count = 0;

                    while (count < 5) {
                        String line = br.readLine();
                        pw.println(line);
                        count++;
                    }
                }catch(IOException e){
                    e.printStackTrace();
                }
                break;
            case "serializare":
                    FileOutputStream fos = new FileOutputStream("student.seri");
                    BufferedOutputStream bos = new BufferedOutputStream(fos);
                    ObjectOutputStream oos = new ObjectOutputStream(bos);

                    System.out.println("Introduceti numele");
                    String nume = br.readLine();
                    System.out.println("Introduceti prenumele");
                    String prenume = br.readLine();
                    System.out.println("Introduceti varsta");
                    int varsta = Integer.parseInt(br.readLine());

                    Student student = new Student(nume, prenume, varsta);

                    try(fos; bos; oos){
                        oos.writeObject(student);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                break;

            case "deserializare":
                FileInputStream fis = new FileInputStream("student.seri");
                BufferedInputStream bis = new BufferedInputStream(fis);
                ObjectInputStream ios = new ObjectInputStream(bis);

                try(fis; bis; ios){
                    Student st = (Student) ios.readObject();
                    System.out.println(st);
                }catch (Exception e){
                    e.printStackTrace();
                }

                break;


        }

    }
}
