import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Exemplul1 {
    public static void main(String[] args) {
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader br = new BufferedReader(isr);

        try(isr; br;){
            System.out.println("Introduceti un mesaj");
            String mesaj = br.readLine();
            System.out.println(mesaj);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
