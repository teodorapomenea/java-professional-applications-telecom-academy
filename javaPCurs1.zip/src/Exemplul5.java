import java.io.*;

public class Exemplul5 {
    public static void main(String[] args) throws FileNotFoundException {
        FileReader fr = new FileReader("src/Exemplul4.java");
        BufferedReader br = new BufferedReader(fr);
        PrintWriter pw = new PrintWriter("Exemplul1Copie.java");

        try(fr; br; pw;) {
            String line;
            line = br.readLine();

            while(line != null){
                pw.println(line);
                line = br.readLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }


    }
}
