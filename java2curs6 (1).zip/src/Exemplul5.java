import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Exemplul5 {
    public static void main(String[] args) throws SQLException {
        Connection con = CreateConnection.getInstance().getConection();

        String sql = "INSERT INTO studenti VALUES(null, ?, ?, ?)";
        PreparedStatement stm = con.prepareStatement(sql);
        stm.setString(1,"Georgescu");
        stm.setString(2,"Larisa");
        stm.setString(3,"larisageorgescu@gmail.com");
        stm.executeUpdate();

    }
}
