import javax.sound.midi.Soundbank;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Exemplul7 {
    public static void main(String[] args) throws SQLException {
        Connection con = CreateConnection.getInstance().getConection();

        Statement stm = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
        String sql = "SELECT * FROM studenti";
        ResultSet rs = stm.executeQuery(sql);
        rs.afterLast();
        System.out.println(rs.isAfterLast());
        rs.previous();
        System.out.println(rs.isAfterLast());
        System.out.println(rs.getString("id") + " " + rs.getString("nume")
                                      + " " + rs.getString("prenume") +" " + rs.getString("mail"));


        rs.previous();
        System.out.println(rs.getString("id") + " " + rs.getString("nume")
                + " " + rs.getString("prenume") +" " + rs.getString("mail"));

    }
}
