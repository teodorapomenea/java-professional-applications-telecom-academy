import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Exemplul2 {
    public static void main(String[] args) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/java2curs6";
        String username = "root";
        String password = "";
        Connection con = DriverManager.getConnection(url, username, password);

        String sql = "INSERT INTO studenti VALUES(null,'Robert', 'Petru', 'robP@gmail.com')";
        PreparedStatement stm = con.prepareStatement(sql);
        stm.executeUpdate();
    }
}
