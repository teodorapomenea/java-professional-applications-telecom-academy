import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Exemplul4 {
    public static void main(String[] args) throws SQLException {
        Connection con = CreateConnection.getInstance().getConection();

        String sql = "DELETE FROM studenti WHERE nume = ?";

        PreparedStatement stm = con.prepareStatement(sql);
        stm.setString(1, "Maria");
        stm.executeUpdate();
        System.out.println("S-au sters inregistrarile");
    }
}
