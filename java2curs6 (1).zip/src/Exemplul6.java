import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Exemplul6 {
    public static void main(String[] args) {
        Connection con = CreateConnection.getInstance().getConection();

        String sql = "UPDATE studenti SET mail = 'mailnou@yahoo' WHERE id = 10";

        try {
            PreparedStatement stm = con.prepareStatement(sql);
            stm.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
