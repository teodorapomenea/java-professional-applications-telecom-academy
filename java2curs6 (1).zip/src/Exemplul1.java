import java.util.List;
import java.util.stream.Stream;

public class Exemplul1 {
    public static void main(String[] args) {
        Stream<String> stream = List.of("a", "bb", "ccc","dddd").parallelStream();
        List<String> list = List.of("a", "bb", "ccc","dddd");

        /*long l1 = System.currentTimeMillis();
            list.stream()
                    .map(e -> processInput(e))
                    .forEach(e -> System.out.println(e));
        long l2 = System.currentTimeMillis();
        System.out.println();
        System.out.println(l2-l1);*/

        long l3 = System.currentTimeMillis();
            stream.map(e -> processInput(e))
                    .forEachOrdered(e -> System.out.println(e));
        long l4 = System.currentTimeMillis();
        System.out.println();
        System.out.println(l4 - l3);

    }

    static Integer processInput(String s){
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return s.length();
    }
}
