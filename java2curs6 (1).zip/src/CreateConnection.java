import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CreateConnection {

    private static Connection con;

    private static CreateConnection instance;

    private CreateConnection(){
        String url = "jdbc:mysql://localhost:3306/java2curs6";
        String username = "root";
        String password = "";
        try {
            con = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static CreateConnection getInstance(){
        if(instance == null){
            instance = new CreateConnection();
        }
        return instance;
    }

    public Connection getConection(){
        return this.con;
    }
}
