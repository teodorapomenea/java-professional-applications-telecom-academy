import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Exemplul3 {
    public static void main(String[] args) throws SQLException {
        Connection con = CreateConnection.getInstance().getConection();
        String sql = "SELECT * FROM studenti";
        PreparedStatement stm = con.prepareStatement(sql);

        ResultSet rs = stm.executeQuery();

        while(rs.next()){
            int id = rs.getInt("id");
            String nume = rs.getString("nume");
            String prenume = rs.getString("prenume");
            String mail = rs.getString("mail");

            System.out.println(id + " " + nume + " " + prenume + " " + mail);
        }
    }
}
