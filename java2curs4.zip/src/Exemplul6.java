import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.ChronoUnit;

public class Exemplul6 {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        System.out.println(localDate);
        LocalDate localDate1 = LocalDate.of(2021,05,12);
        System.out.println(localDate1);
        LocalDate localDate2 = LocalDate.of(1999, Month.DECEMBER, 25);
        System.out.println(localDate2);

        localDate2 = localDate2.plusDays(10);
        System.out.println("Plus days " + localDate2);
        System.out.println(localDate.plus(2, ChronoUnit.WEEKS));

        System.out.println();
        System.out.println(localDate1.getDayOfMonth());
        System.out.println(localDate1.getDayOfWeek());
        System.out.println(localDate1.getDayOfYear());

        System.out.println(localDate.isBefore(localDate2));
    }
}
