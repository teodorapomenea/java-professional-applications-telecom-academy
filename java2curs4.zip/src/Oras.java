import java.util.Objects;

public class Oras {

    private String nume;
    private int nrLocuitori;
    private double suprafata;

    public Oras(String nume, int nrLocuitori, double suprafata) {
        this.nume = nume;
        this.nrLocuitori = nrLocuitori;
        this.suprafata = suprafata;
    }

    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public int getNrLocuitori() {
        return nrLocuitori;
    }

    public void setNrLocuitori(int nrLocuitori) {
        this.nrLocuitori = nrLocuitori;
    }

    public double getSuprafata() {
        return suprafata;
    }

    public void setSuprafata(double suprafata) {
        this.suprafata = suprafata;
    }

    @Override
    public String toString() {
        return nume;
    }

    /*@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Oras)) return false;
        Oras oras = (Oras) o;
        return this.getNume().equals(oras.getNume());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNume());
    }*/
}
