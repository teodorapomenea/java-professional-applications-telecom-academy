import java.util.Optional;

public class Exemplul3 {
    public static void main(String[] args) {
        Optional<String> op = Optional.empty();
        System.out.println(op.isEmpty());
        Optional<String> op2 = Optional.of(":)");
        System.out.println(op2.isPresent());
        System.out.println(op2.get());

        String s = null;
        Optional<String> op3 = Optional.ofNullable(s);
        System.out.println("Op Nullable " + op3.isEmpty());

        op3.ifPresent(e -> System.out.println(e));
        op3.ifPresentOrElse(e -> System.out.println(e), () -> System.out.println("Optional gol"));

        String parametru = "Maria";
        String rezultat = Optional.ofNullable(parametru).orElse(metoda());
        System.out.println(rezultat);
        String rezultat2 = Optional.ofNullable(parametru).orElseGet(() -> metoda());
        System.out.println(rezultat2);
    }

    public static String metoda(){
        System.out.println("Apelul metodei");
        return "Or else get";
    }
}
