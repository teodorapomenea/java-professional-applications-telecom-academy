import java.time.*;
import java.time.temporal.ChronoUnit;

public class Exemplul9 {
    public static void main(String[] args) {
        Period an = Period.ofYears(2);

        System.out.println(LocalDate.now().plus(an));

        Period zi = Period.ofDays(12);
        Period p1 = Period.parse("P2Y10M0D");
        System.out.println(LocalDate.now().plus(p1));

        LocalDate localDate = LocalDate.now();
        LocalDate localDate1 = LocalDate.of(2000,01,23);
        Period intre =Period.between(localDate1, localDate);
        System.out.println(intre);

        Duration duration = Duration.of(2, ChronoUnit.MINUTES);
        Duration duration1 = Duration.ofHours(12);

        LocalTime localTime = LocalTime.now();
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime.plus(duration));

    }
}
