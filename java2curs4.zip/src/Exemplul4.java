import java.util.Calendar;
import java.util.Date;

public class Exemplul4 {
    public static void main(String[] args) {
        Date date = new Date();
        System.out.println(date);
        Calendar calendar = Calendar.getInstance();
        System.out.println(calendar.getTime());
    }
}
