import java.util.stream.IntStream;
import java.util.stream.LongStream;

public class Exemplul1 {
    public static void main(String[] args) {
        IntStream.iterate(0, e -> e+1)
                    .limit(10)
                    .forEach(System.out::println);

        long l = LongStream.rangeClosed(10, 100)
                           .sum();



    }
}
