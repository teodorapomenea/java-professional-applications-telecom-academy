import java.util.Locale;

public class Exemplul11 {
    public static void main(String[] args) {
        Locale loc = Locale.getDefault();
        System.out.println(loc);
        Locale loc1 = Locale.FRANCE;
        System.out.println(loc1.getLanguage());
        Locale loc2 = new Locale("fr","FR");
        Locale loc3 = new Locale.Builder()
                                .setLanguage("ro")
                                .setRegion("RO")
                                .build();

        System.out.println(loc3);

    }
}
