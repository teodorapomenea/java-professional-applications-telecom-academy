import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OrasInterface {
    private OrasInterface(){}

    public static long getNumarOrase(List<Oras> lista){
        Stream<Oras> s1 = lista.stream().filter(e -> e.getNume().startsWith("B"));
        return s1.count();
    }

    public static Map<Boolean, List<String>> getGrupOrase(List<Oras> listaOrase/* String litera*/){
        return listaOrase.stream()
                         .map(e -> e.getNume())
                         .distinct()
                         .collect(Collectors.partitioningBy(e -> e.startsWith("A")));
    }

    public static Map<Double, List<Oras>> groupByDensitate(List<Oras> listaOrase){
        return listaOrase.stream()
                        .collect(Collectors.groupingBy(e -> e.getNrLocuitori() / e.getSuprafata() ));
    }

}
