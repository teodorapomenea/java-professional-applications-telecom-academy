import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class Exemplul10 {
    public static void main(String[] args) {
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy/MM/dd");
        //y -> ani
        //d -> zi
        //M-> luna
        //m -> minute
        //h ->ore
        //s -> secunde

        String date = "1989/12/25";
        LocalDate localDate = LocalDate.parse(date, dateTimeFormatter);

        System.out.println(localDate);
        DateTimeFormatter dateTimeFormatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        System.out.println(localDate.format(dateTimeFormatter1));

        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("hh-ss");
        LocalTime localTime = LocalTime.now();
        System.out.println(localTime.format(timeFormatter));

        DateTimeFormatter dateTimeFormatterFull = DateTimeFormatter.ofLocalizedDateTime(FormatStyle.FULL);

        LocalDateTime localDateTime = LocalDateTime.now();
        ZonedDateTime zonedDateTime = ZonedDateTime.of(localDateTime, ZoneId.of("Europe/Madrid"));

        System.out.println(zonedDateTime.format(dateTimeFormatterFull));

    }
}
