import javax.print.attribute.standard.NumberOfDocuments;
import java.text.NumberFormat;
import java.util.Locale;

public class Exemplul12 {
    public static void main(String[] args) {
        Locale loc1 = Locale.US;
        NumberFormat usNumberFormat = NumberFormat.getInstance(loc1);
        NumberFormat frNumberFormat = NumberFormat.getInstance(Locale.FRANCE);

        System.out.println(usNumberFormat.format(12.3));
        System.out.println(frNumberFormat.format(12.3));

        NumberFormat usCurrency = NumberFormat.getCurrencyInstance(loc1);
        NumberFormat frCurrency = NumberFormat.getCurrencyInstance(Locale.FRANCE);

        System.out.println(usCurrency.format(12.3));
        System.out.println(frCurrency.format(12.3));

    }
}
