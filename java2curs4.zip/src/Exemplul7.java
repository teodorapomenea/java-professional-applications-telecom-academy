import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Exemplul7 {
    public static void main(String[] args) {
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println(localDateTime);
        System.out.println(LocalDateTime.MAX);
        LocalDateTime localDateTime1 = LocalDateTime.of(2021,05,25,11,22, 12, 23);
        System.out.println(localDateTime1);

        LocalDate date = LocalDate.of(2021,05,11);
        LocalTime time = LocalTime.parse("11:22:23");
        LocalDateTime localDateTime2 = LocalDateTime.of(date, time);

        LocalDateTime localDateTime3 = LocalDateTime.parse("2020-05-08T21:23:25");

        System.out.println(localDateTime.plus(2, ChronoUnit.MINUTES));
        System.out.println(localDateTime.getDayOfYear());


    }
}
