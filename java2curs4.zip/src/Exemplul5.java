import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class Exemplul5 {
    public static void main(String[] args) {
        LocalTime localTime = LocalTime.now();
        System.out.println(localTime);
        LocalTime localTime1 = LocalTime.of(12,23,2);
        System.out.println(localTime1);
        LocalTime localTime2 = LocalTime.parse("15:20");

        System.out.println(localTime1.getHour());
        System.out.println(localTime.isBefore(localTime1));

        LocalTime plusHours = localTime.plusHours(1);
        System.out.println(plusHours);

        System.out.println(plusHours.plus(2, ChronoUnit.MINUTES));
        System.out.println(plusHours.minusHours(3));
    }
}
