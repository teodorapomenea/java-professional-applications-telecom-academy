import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Exemplul2 {
    public static void main(String[] args) {
        List<Oras> listaOrase = List.of(
                new Oras("Bucuresti", 5000, 600),
                new Oras("Constanta", 5000, 600),
                new Oras("Brasov", 1500, 500),
                new Oras("Bucuresti", 5000, 600),
                new Oras("Constanta", 6000, 523),
                new Oras("Suceava", 2500, 690),
                new Oras("Iasi", 2500, 690),
                new Oras("Timisoara", 6966, 5487)
        );

        List<String> numeOrase = new ArrayList<>();
        listaOrase.stream().filter(e -> e.getNrLocuitori() > 1000).distinct().forEach(a -> numeOrase.add(a.getNume()));
        numeOrase.forEach(System.out::println);

        //.collect(Collectors.toList())

        List<String> numeOrase2 = listaOrase.stream()
                .filter(e -> e.getNrLocuitori() > 1000)
                .map(e -> e.getNume())
                .distinct()
                .collect(Collectors.toList());

        //numeOrase2.forEach(System.out::println);
        //System.out.println(OrasInterface.getNumarOrase(listaOrase));

        Map<Boolean, List<String>> map = listaOrase.stream().map(Oras::getNume).collect(Collectors.partitioningBy(nume -> nume.charAt(0) == 'A'));
        map.forEach((k,v) -> System.out.println(k + " "  + v));
        System.out.println(OrasInterface.groupByDensitate(listaOrase));
    }
}