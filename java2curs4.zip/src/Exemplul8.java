import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Exemplul8 {
    public static void main(String[] args) {
        ZoneId defaultId = ZoneId.systemDefault();
        System.out.println(defaultId);
        //ZoneId.getAvailableZoneIds().forEach(e -> System.out.println(e));
        ZoneId parsedId = ZoneId.of("Canada/Central");

        ZonedDateTime zonedDateTime = ZonedDateTime.now();
        System.out.println(zonedDateTime);

        LocalTime time = LocalTime.of(12,25,22);
        LocalDate date = LocalDate.now();

        ZonedDateTime zonedDateTime1 = ZonedDateTime.of(date, time, parsedId);
        System.out.println(zonedDateTime1.getDayOfYear());
    }
}
