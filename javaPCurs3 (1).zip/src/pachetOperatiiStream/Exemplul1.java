package pachetOperatiiStream;

import java.util.List;

public class Exemplul1 {
    public static void main(String[] args) {
        //Preia primele 3  pare elementele distincte pare ale unei lista
        List<Integer> lista = List.of(1,8,2,4,3,6,3,5,2,8,9,10);

        lista.stream().distinct()
                      .sorted()
                      .filter(e -> e % 2 == 0)
                      .limit(3)
                      .forEach(System.out::println);


    }
}
