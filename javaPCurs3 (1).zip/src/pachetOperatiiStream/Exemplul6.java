package pachetOperatiiStream;

import java.util.List;

public class Exemplul6 {
    public static void main(String[] args) {
        List<Integer> lista =  List.of(1,2,3,5,6,89,7);

        boolean b1 = lista.stream().allMatch( e -> e > 10);
        boolean b2 = lista.stream().anyMatch(e -> e > 10);
        boolean b3 = lista.stream().noneMatch(e -> e > 10);

        System.out.println("All Match " + b1);
        System.out.println("Any Math " + b2);
        System.out.println("None match " + b3);
    }
}
