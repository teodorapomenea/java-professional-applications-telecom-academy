package pachetOperatiiStream;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Exemplul7 {
    public static void main(String[] args) {
        List<String> list = List.of("Maria", "Ioana", "Cristi", "Dorin");

        List<Integer> listaLungimi = list.stream()
                                        .map(String::length)
                                        .collect(Collectors.toList());

        Set<String> set = list.stream()
                                .map(String::toUpperCase)
                                .collect(Collectors.toSet());

        TreeSet<String> ts = list.stream()
                                    .map(String::toLowerCase)
                                    .collect(Collectors.toCollection(TreeSet::new));

        Map<String, Integer> map = list.stream()
                                        .collect(Collectors.toMap(e -> e, e -> e.length()));

    }
}
