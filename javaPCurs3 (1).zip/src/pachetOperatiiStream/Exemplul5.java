package pachetOperatiiStream;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Exemplul5 {
    public static void main(String[] args) {
        List<Integer> lista = List.of(1,2,3,6,5,4,8,5);
        Integer rez = lista.stream().reduce(0, (e1, e2) -> e1 + e2);

        Optional<String> op = Stream.of("Bucuresti", "Craiova", "Iasi").reduce((a, b) -> a + " . " + b);
        System.out.println(op.get());
    }
}
