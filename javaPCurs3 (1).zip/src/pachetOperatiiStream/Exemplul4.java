package pachetOperatiiStream;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Exemplul4 {
    public static void main(String[] args) {
        //Prea un tream de string il transporma intr-un stream de inturi
        List<String> lista = List.of("Brasov", "Craiova", "Bucuresti", "Timisoara");
        List<String> lista2 = List.of("Brasov", "Craiova", "Bucuresti", "Timisoara");

        List<Integer> lungimi =   lista.stream()
                                        .map(e -> e.length()) // > Stream<Integer>
                                        .collect(Collectors.toList());

        lungimi.forEach(e -> System.out.println(e));

        Stream<Integer> streamInteger = lista.stream()
                                         .map(String::length); // e -> e.length()

        List<Integer> lungimi2 = streamInteger.collect(Collectors.toList());

        List<List<String>> lista3 = List.of(lista, lista2);

        List<String> listaFlatMap=    lista3.stream()
                                            .flatMap(e -> e.stream())
                                            .collect(Collectors.toList());

        listaFlatMap.forEach(System.out::println);
    }
}
