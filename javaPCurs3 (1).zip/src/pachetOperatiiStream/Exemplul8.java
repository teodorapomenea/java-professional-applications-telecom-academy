package pachetOperatiiStream;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Exemplul8 {
    public static void main(String[] args) {
        List<String> lista = List.of("Maria", "Ioana", "Cristi", "Dorin", "Ion");

        String allElements = lista.stream().collect(Collectors.joining(","));
        System.out.println(allElements);

        Map<Integer, List<String>> map = lista.stream()
                                        .collect(Collectors.groupingBy(e -> e.length()));

        System.out.println(map);

        Map<Integer, Long> map2 = lista.stream()
        .collect(Collectors.groupingBy(e -> e.length(), Collectors.counting()));

        System.out.println(map2);

        lista.stream()
            .collect(Collectors.partitioningBy(e -> e.startsWith("I"))).
    forEach((k,v) -> System.out.println(k + " " + v));

}
}
