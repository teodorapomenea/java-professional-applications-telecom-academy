package pachetOperatiiStream;

import java.util.List;

public class Exemplul2 {
    public static void main(String[] args) {
        List<String> lista = List.of("dsfds", "rgbwuy","adyjea","dsfds", "adyjea", "rgbwuy", "sdafea", "aruknmsea");
        //Numarul elementelor care inceap cu a si sa se termine cu ea
        long i = lista.stream().distinct()
                              .filter(e -> e.startsWith("a") & e.endsWith("ea"))
                              .count();
        System.out.println(i);
    }
}
