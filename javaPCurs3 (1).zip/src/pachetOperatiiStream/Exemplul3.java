package pachetOperatiiStream;

import java.util.stream.Stream;

public class Exemplul3 {
    public static void main(String[] args) {
        //Dintr-un strem infinit sa preia toate elementele < 100
        Stream<Integer> stm = Stream.iterate(1, i -> ++i);
        stm.takeWhile(e -> e < 100).forEach(e -> System.out.println(e));
    }
}
