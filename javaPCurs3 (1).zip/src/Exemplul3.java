import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

public class Exemplul3 {
    public static void main(String[] args) {
        //Consumer care sa adauge elemente intr-o lista
        //BiConsumer care sa adauge elemente intr-un Map<Integer, String>

        ArrayList<Integer> lista = new ArrayList<Integer>();
        Map<Integer, String> map = new HashMap<Integer, String>();

        Consumer<Integer> consumer = i -> lista.add(i);
        consumer.accept(1);
        consumer.accept(2);
        System.out.println(lista);

        BiConsumer<Integer, String> biConsumer = (i, s) -> map.put(i,s);
        biConsumer.accept(1,"Maria");
        biConsumer.accept(2,"Ioana");
        System.out.println(map);

    }
}
