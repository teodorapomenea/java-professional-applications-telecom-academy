import java.util.List;
import java.util.stream.Stream;

public class Exemplul4 {
    public static void main(String[] args) {
        Stream<Integer> s1 = Stream.empty();

        Stream<Integer> s2 = Stream.of(1,2,3,4,5);
        s2.forEach(e -> System.out.println(e));

        List<Integer> lista = List.of(1,2,3,4,5,6,7,8);
        Stream<Integer> s3 = lista.stream();

        System.out.println();

        Stream<Double> s4 = Stream.generate(() -> Math.random());
        s4.limit(10).forEach(System.out::println);

        Stream<Integer> s5 = Stream.iterate(0, i -> ++i);
        System.out.println();
        // i = ++i;
        s5.limit(5).forEach(System.out::println);

    }
}
