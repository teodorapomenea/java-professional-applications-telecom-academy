public interface SumInterface {
    public void suma(int a, int b);

    default void metodaDefault(){
        System.out.println("Metoda conceta");
    }

    static void metodaStatica(){
        System.out.println("Metoda statica");
    }
}
