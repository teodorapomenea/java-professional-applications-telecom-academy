public class Student {
    String nume;

    public Student(String nume) {
        this.nume = nume;
    }

    public String sayHi(){
        return "Hello";
    }
}
