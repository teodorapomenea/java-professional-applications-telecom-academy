@FunctionalInterface
public interface DifInterface {
    public double diferenta(int a);
}
