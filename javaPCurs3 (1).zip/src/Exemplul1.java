public class Exemplul1 {
    public static void main(String[] args) {
        SumInterface s1 = new SumInterface(){
            @Override
            public void suma(int x, int y){
                System.out.println(x + y);
            }
        };

        s1.suma(1,2);

        SumInterface s2 = (x,y) -> System.out.println(x + y);

        DifInterface d1 = a -> {return a + 1;};
        System.out.println(d1.diferenta(3));

        DifInterface d2 = (a) -> a + 1;
        DifInterface d3 = a -> a + 1;

        Student s = new Student("Maria");

        StudentInterface stI = () -> {
                                     System.out.println(":)");
                                     return s.sayHi();
                                     };


        StudentInterface stI2 = s::sayHi;
        //forEach(System.out::println)

    }
}
