import java.awt.geom.Arc2D;
import java.util.function.*;

public class Exemplul2 {
    public static void main(String[] args) {
        Supplier<String> sp1 = () -> "Mira";
        System.out.println(sp1.get());

        Consumer<Integer> consumer = (i) -> System.out.println(i);
        consumer.accept(10);

        BiConsumer<String, Integer> biConsumer = (s, i) -> System.out.println(s.length() + i);
        biConsumer.accept("mere", 2);

        Predicate<String> p = (s) -> s.isEmpty();
        System.out.println(p.test("ss"));
        //un string are mai mult de 3 caractere

        Predicate<String> p1 = s -> {return s.length() > 3;};

        BiPredicate<String, Integer> biPredicate = (s,i) -> s.length() > i;

        Function<String, Integer> fct = s -> s.length();

        //BiFucntion -> returneaza suma lg a doua stringuri
        BiFunction<String, String, Integer> biFct = (s,s1) -> s.length()+s1.length();
        System.out.println(biFct.apply("string1", ":)"));

        UnaryOperator<Double> unaryOperator = i -> i + 1;
        double d = unaryOperator.apply(1.0);

        BinaryOperator<Integer> binaryOperator = (a,b) -> a + b;

        IntFunction<Integer> intFunction = i -> ++i;
        intFunction.apply(1);

        ToIntFunction<Integer> toIntFunction = i -> ++i;
        int a = toIntFunction.applyAsInt(23);
        System.out.println("a " + a);

        DoubleToIntFunction doubleToIntFunction = i -> 1;
        int x = doubleToIntFunction.applyAsInt(2.3);
    }
}
