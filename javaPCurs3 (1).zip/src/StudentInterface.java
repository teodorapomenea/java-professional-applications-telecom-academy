public interface StudentInterface {
    String hello();
}
